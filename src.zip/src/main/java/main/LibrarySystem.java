package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LibrarySystem {

    private List<Item> items;
    private final FileHandler fileHandler;
    private final Scanner scanner;

    public LibrarySystem() {
        items = new ArrayList<>();
        fileHandler = new TextFileHandler();
        scanner = new Scanner(System.in);
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(String id) {

        Item found = null;

        for (Item item : items) {
            if (item.getId().equals(id)) {
                found = item;
                break;
            }
        }

        if (found != null) {
            items.remove(found);
            System.out.println("Item removed successfully.");
        } else {
            System.out.println("Item not found.");
        }
    }

    public void listAllItems() {
        for (Item item : items) {
            System.out.println(item);
        }
    }

    public void searchByTitle(String title) {

        boolean found = false;

        for (Item item : items) {
            if (item.getTitle().toLowerCase()
                    .contains(title.toLowerCase())) {

                System.out.println(item);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No items found with that title.");
        }
    }

    public void saveToFile() {
        System.out.println("Enter filename to save:");
        String filename = scanner.nextLine();
        fileHandler.saveItems(filename, items);
    }

    public void loadFromFile() {
        System.out.println("Enter filename to load:");
        String filename = scanner.nextLine();
        items = fileHandler.loadItems(filename);
    }

    public void displayMenu() {

        System.out.println("=== Library Management System ===");
        System.out.println("1. Add new Book");
        System.out.println("2. Add new DVD");
        System.out.println("3. Remove item");
        System.out.println("4. List all items");
        System.out.println("5. Search by title");
        System.out.println("6. Save to file");
        System.out.println("7. Load from file");
        System.out.println("8. Exit");
        System.out.println("Enter your choice:");
    }

    public void start() {

        int choice;

        do {

            displayMenu();
            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {

                case 1:
                    System.out.println("Enter book ID:");
                    String bookId = scanner.nextLine();

                    System.out.println("Enter title:");
                    String bookTitle = scanner.nextLine();

                    System.out.println("Enter author:");
                    String author = scanner.nextLine();

                    addItem(new Book(bookId, bookTitle, author));
                    System.out.println("Book added successfully.");
                    break;

                case 2:
                    System.out.println("Enter DVD ID:");
                    String dvdId = scanner.nextLine();

                    System.out.println("Enter title:");
                    String dvdTitle = scanner.nextLine();

                    System.out.println("Enter duration (minutes):");
                    int duration = Integer.parseInt(scanner.nextLine());

                    addItem(new DVD(dvdId, dvdTitle, duration));
                    System.out.println("DVD added successfully.");
                    break;

                case 3:
                    System.out.println("Enter item ID to remove:");
                    String removeId = scanner.nextLine();
                    removeItem(removeId);
                    break;

                case 4:
                    listAllItems();
                    break;

                case 5:
                    System.out.println("Enter title to search for:");
                    String search = scanner.nextLine();
                    searchByTitle(search);
                    break;

                case 6:
                    saveToFile();
                    break;

                case 7:
                    loadFromFile();
                    break;

                case 8:
                    System.out.println("Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice.Please try again.");
            }

        } while (choice != 8);
    }
}